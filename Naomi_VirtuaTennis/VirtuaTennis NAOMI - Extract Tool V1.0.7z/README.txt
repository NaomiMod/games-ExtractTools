-------------------------------------
VirtuaTennis NAOMI Extract Tool V1.0

By Vincent 27/01/2021
------------------------------------

This tool will extract game resources by using multiple QBMS on your own legally dumped
VirtuaTennis NAOMI game.
In order to perform all operations, third party tools are required:

(You'll need the following programs EXTRACTED into the "Scripts_Tools" folder)

DOSPVR            (Included in Sega PVR Tools) 
Pvr2Png           https://www.google.com/search?&q=pvr2png+dreamcast
quickbms          https://aluigi.altervista.org/quickbms.htm

--------
Optional
--------

DTPKutil



------------

HOW TO USE

------------


1) Extract this archive to any folder of your choice

2) Place vtennis.zip in the same folder

3) Run the bat script


--------

Optional

--------

1) To extract Audio SFX, open the audio files .SND with DTPKutil and click on EXTRACT Samples



----------------

LEGAL DISCLAIMER

----------------

This project is intended exclusively for educational purposes and has no affiliation with SEGA or any other third party developer.
Virtua Tennis resources are exlusive property of SEGA and CANNOT BE DISTRUBUTED.
VirtuaTennis NAOMI Extract Tool V1.0 is a recreative project, no compensation has been offered for research and will not be accepted in any form.


